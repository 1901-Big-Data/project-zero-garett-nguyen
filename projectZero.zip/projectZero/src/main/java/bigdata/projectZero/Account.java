package bigdata.projectZero;

import java.sql.*;
import java.util.Scanner;

public class Account {
	String accountUser;
	
	public Account(String username) {
		accountUser = username;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to your bank account, " + accountUser +"!\n");
		AccountDao adao = new AccountDao();
		
		while (true) {
			//Infinite option select unless the user signs out with option 5
			System.out.println("Press 1 to view your account balance");
			System.out.println("Press 2 to withdraw to your account");
			System.out.println("Press 3 to deposit from your account");
			System.out.println("Press 4 to deactivate your account.");
			System.out.println("Press 5 to log out of your account");
			boolean isoption = false;
				do {
					String option = sc.nextLine();
						
					if (option.equals("1")) {
						isoption = true;
						//adao.viewBalance(username);
						
						System.out.println("Your account balance is: $" + adao.viewBalance(username));
					
			    		
					}
					else if (option.equals("2")) {
						isoption = true;
						boolean isDepositable = false;
						do {
							int amount;
							System.out.println("Enter an integer amount of money you'd like to withdraw.");
							try {
								amount = sc.nextInt();
								int balance = adao.viewBalance(username);
								if (amount > balance) {
									System.out.println("Withdraw amount exceeds account balance.");
								}
								else if (amount == balance) {
									adao.setBalance(username, 0);
								}
								else if (amount < balance) {
									adao.setBalance(username, balance - amount);
								}
								
								System.out.println("Your account balance after withdrawal is: $" + adao.viewBalance(username));
								isDepositable = true;
							}
							catch (Exception e) {
								System.out.println("Invalid input. Only integers please.");
							}
							
						}
						while (!isDepositable);
					}
					else if (option.equals("3")) {
						isoption = true;
						int amount = 0;
						int balance = adao.viewBalance(username);
						boolean isintamount = false;
						do {
							System.out.println("Enter an integer amount of money you'd like to deposit.");
							try {
								amount = sc.nextInt();
								adao.setBalance(username, balance + amount);
								
								System.out.println("Your account balance after deposit is: $" + adao.viewBalance(username));
								isintamount = true;
							}
							catch (Exception e) {
								System.out.println("Invalid input. Only integers please.");
							}
						}
						while (!isintamount);
						
					}
					else if (option.equals("4")) {
						isoption = true;
						System.out.println("Deleting your account will delete all of your data, and cause you to log out.");
						System.out.println("Are you sure you want to continue? y/n");
						boolean isyon = false;
						try {
							do {
								String s = sc.next();
								if (s.equals("y")) {
									int amount = adao.viewBalance(username);
									if (amount == 0) {
										adao.deleteAccount(username);
										isyon = true;
										System.out.println("Deleted account successfully. Logging out.");
										System.exit(0);
									}
									else {
										System.out.println("Cannot delete from accounts with money in balance.");
									}
								}
								if (s.equals("n")) {
									isyon = true;
								}	
									
							}
							while (isyon);
						}
						catch (Exception e) {
							System.out.println("Could not delete.");
						}
					}
					else if (option.equals("5")) {
						isoption = true;
						System.out.println("Successfully logged out.");
						System.exit(0);
					}
					else {
						System.out.println("Only 1 or 2, please.");
					}
					
				}
				while (!isoption);
		}
	}
}
