package bigdata.projectZero;

import java.sql.*;

import java.util.Optional;



public class App
{
    public static void main( String[] args ) throws SQLException
    {
    	   	
    	login log = new login();
    }
}
