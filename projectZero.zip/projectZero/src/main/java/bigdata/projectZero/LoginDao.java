package bigdata.projectZero;

import java.sql.*;

public class LoginDao {

	
	protected LoginDao() {
		
	}
	protected Account grantAccessAccount(String[] credentials) {
		try {
			boolean verified = false;
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankaccounts", "root", "Darkflamemaster82!");
			PreparedStatement myStat = myConn.prepareStatement("Select * from accounts WHERE username=\"" + credentials[0] + "\" AND password= \"" + credentials[1]+"\"");
			ResultSet myRs = myStat.executeQuery("Select * from accounts WHERE username=\"" + credentials[0] + "\" AND password= \"" + credentials[1]+"\"");                                              
	
			
			

			if (myRs.next()) {
				verified = true; 
				System.out.println("Logon was successful");
			}
			
			myConn.close();
			
			if (verified) {
				//Instance of account. Account runs as the constructor
				Account acc = new Account(credentials[0]);
				return acc;
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Logon was unsucessful.\n");
		return null;
		
	}
	protected boolean checkUsernameReq(String username) {
		if (username != null) {
			if (username.length() > 5) {
				//creates an SQL query for the username within the JDBC database. If a match is found, must return false;
				return true;
			}
			else {
				System.out.println("Must have Username with length of at least 5 characters.");
			}
		}
		return false;
	}
	protected boolean checkPasswordReq(String password) {
		return (password != null);
	}
	protected void createNewAccount(String[] newcredentials ) {
		try {
			Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankaccounts", "root", "Darkflamemaster82!");
			PreparedStatement myStat = myConn.prepareStatement("INSERT INTO accounts (username, password, money) VALUES ('"+ newcredentials[0]+"', '"+newcredentials[1]+ "', 0);");
			myStat.executeUpdate();   
			
			myConn.close();
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("There was a problem with making a new account.");
		}
	}
	protected void requestAccountAccess() {
		
	}
}
