package bigdata.projectZero;


import java.util.logging.*;

public interface Logon {
	public void relayCredentials(String[] credentials);
	public void notifyUser();
	
	
}
