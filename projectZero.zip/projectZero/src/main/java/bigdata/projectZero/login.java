package bigdata.projectZero;

import java.io.Console;
import java.util.Scanner;

public class login implements Logon {
	
	private LoginDao superuser;
	//private Console c;
	private boolean verified;
	private Scanner sc;
	
	public login() {
		verified = false;
		superuser = new LoginDao();
		//c = System.console();
		sc = new Scanner(System.in);
		
		/*
		if (c == null) {
	            System.err.println("No console.");
	            System.exit(1);
	    }
	    */
		//Sign in message
		System.out.println("\n\n\n");
		System.out.println("**********************************************************************************************************************\n\n\n");
		System.out.println("---------------------Welcome! Would you like to sign in to your bank account or create a new one?---------------------\n");
		System.out.println("Press 1 to sign in");
		System.out.println("Press 2 to create an account");
		
		//Option Select: sign in or create account
		boolean isoption = false;
		do {
			String option = sc.nextLine();
			
			if (option.equals("1")) {
				isoption = true;
				UserLogin();
			}
			else if (option.equals("2")) {
				isoption = true;
				UserCreateAccount();
			}
			else {
				System.out.println("Only 1 or 2, please.");
			}
			
		}
		while (!isoption);
		
	}
	public void UserLogin() {	
		int loginAttempt = 0;
        do {
        	//if first attempted login fails, this will repeat until attempts are reached (4)
        	if (loginAttempt != 0 && !verified) {
        		System.out.println("Login attempt failed. Please try again. Attempts remaining: " + (4-loginAttempt));
        	}
        
        	String[] credentials = new String[2];
        	
        	System.out.print("Enter your username: ");
        	credentials[0] = sc.nextLine();
        	System.out.print("Enter your password: ");
            credentials[1]= sc.nextLine();
            
            loginAttempt++;
            String[] copy = credentials;
            Account acc;
            acc = superuser.grantAccessAccount(copy);
            
            if (acc != null) {
            	verified = true;
            }         
        }
        while (loginAttempt < 4 && !verified);
        if (loginAttempt >= 4) {
        	System.out.println("Login attempts reached. Program exiting.");
        }
	}
	public void UserCreateAccount() {
		boolean hasUsernameReq = false;
		boolean hasPasswordReq = false; 
		boolean createsuccessful = false;
		
		//creates username and passwords with correct requirements. Checks database for duplicate usernames as well.
		do {
			String[] newcredentials = new String[2];
			//newcredentials[0] = c.readLine("Type in a Username for your new account: ");
			//newcredentials[1] = c.readPassword("Type in a Password for your new account: ").toString();
			
			System.out.println("Type in a Username for a new account: ");
			newcredentials[0] = sc.nextLine();
			System.out.println("Type in a Password for your new account: ");
			newcredentials[1] = sc.nextLine();
			
			hasUsernameReq = superuser.checkUsernameReq(newcredentials[0]);
			hasPasswordReq = superuser.checkPasswordReq(newcredentials[1]);
			
			if (hasPasswordReq && hasUsernameReq) {
				superuser.createNewAccount(newcredentials);
			}
		}
		while (!hasUsernameReq || !hasPasswordReq);
		
	}
	public void relayCredentials(String[] credentials) {
		superuser.grantAccessAccount(credentials);
	}
	public void notifyUser() {
		
	}
	
	
	
}
